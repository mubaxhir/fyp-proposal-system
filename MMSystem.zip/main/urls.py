from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
        path('', views.index, name='signin'),
        path('signin/', views.signin, name='signin'),
        path('students', views.students, name='students'),
        path('members', views.members, name='member'),
        path('proposal', views.student_proposal_details, name='student_proposal_details'),
        path('create_user', views.create_user, name='create_user'),
        path('logout', views.logout_view, name='logout')
]